package application;

public class LoginException extends Exception
{
  public LoginException(String message) 
  {
	// TODO Auto-generated constructor stub
	  super(message);
	  
  }
 	
}