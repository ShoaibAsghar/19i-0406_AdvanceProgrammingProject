package application;

public class SearchBike_IDException extends Exception
{
	 public SearchBike_IDException (String message) 
	 {
		// TODO Auto-generated constructor stub
		 super(message);
	}
	 	
}