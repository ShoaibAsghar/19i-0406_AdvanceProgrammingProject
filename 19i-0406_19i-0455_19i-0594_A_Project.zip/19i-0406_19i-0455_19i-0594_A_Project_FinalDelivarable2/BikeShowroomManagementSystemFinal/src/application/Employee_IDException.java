package application;

public class Employee_IDException extends Exception
{
	 public Employee_IDException (String message) 
	 {
		// TODO Auto-generated constructor stub
		 super(message);
	}
	 	
}