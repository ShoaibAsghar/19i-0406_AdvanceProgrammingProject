package application;

public class CNICException extends Exception
{
	public CNICException(String message) 
	  {
		// TODO Auto-generated constructor stub
		  super(message);
		  
	  }
	
}