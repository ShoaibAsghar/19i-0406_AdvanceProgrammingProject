package application;

public class Supplier {

	private String supplierId;
	private String address;
	private String contactNo;
	private String supplyBike;
	private String bikeMaterials;
}
