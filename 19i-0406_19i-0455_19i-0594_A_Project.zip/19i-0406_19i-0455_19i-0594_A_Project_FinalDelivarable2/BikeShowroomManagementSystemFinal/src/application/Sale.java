package application;

public class Sale {

	public void ShowBikes() throws ClassNotFoundException {
		Bike bike = new Bike();
		bike.ShowBikes();
		
	}

	public void createSale() {
		
		
	}

}
