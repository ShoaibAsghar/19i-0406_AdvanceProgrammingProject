package application;

public class Payment {

	private int Payment_id;
	private int Customer_id;
	private String date;
	private String paymentBill;
}
