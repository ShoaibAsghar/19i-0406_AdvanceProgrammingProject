package application;

public class Receipt {

}
