package application;

public class Employee {
	
	private String name;
	private int id;
	private String address;

}
