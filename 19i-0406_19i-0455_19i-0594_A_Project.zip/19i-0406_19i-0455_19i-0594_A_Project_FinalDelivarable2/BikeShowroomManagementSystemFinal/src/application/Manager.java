package application;

public class Manager {
	
	private String managerName;
	private String managerId;
	private String location;
	

}
