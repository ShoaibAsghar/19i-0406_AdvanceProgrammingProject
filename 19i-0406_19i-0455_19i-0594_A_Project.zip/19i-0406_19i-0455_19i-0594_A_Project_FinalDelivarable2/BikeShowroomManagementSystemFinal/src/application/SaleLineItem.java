package application;

import java.util.ArrayList;
import java.util.List;

public class SaleLineItem {
	
	List<Integer> bikes = new ArrayList();

}
